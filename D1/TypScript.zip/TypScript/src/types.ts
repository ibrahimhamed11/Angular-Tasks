var fristNAme :string;
fristNAme = "jjjjjj"
var age :number = 26;
var IsMale :boolean =false;

//IsMale = "ah" //error

////Array
let items :Array<number|string|null> = [2,4,4,"bbb",null]
let ids:Array<any> = [false]
let item :number[] = [2,4,4]
// let item :any[] = [2,4,4]


let test :any 
test = "kero"
console.log(typeof test)
test = false
console.log(typeof test)
// String

//tuples
var t :[number,string,boolean][]=[]

t.push([1,"gggg",false])
t.push([1,"00000",true])
t.push([3,"jjjjj",true])
t.push([4,"pppp",true])


for (let index = 0; index < t.length; index++) {
    console.log(typeof t[index]);
    
}

