import { gender } from "./enum";
interface IPerson{
    Name:string;
    age:number;
    gender :gender;
    sayHi:()=>string;

    print(n:string):string
}


//use
let emp :IPerson 
emp = {
    Name:"hhhhh",
    age:3,
    gender:gender.male,
    sayHi :function (){
        return this.name
    },
    print:fun
}





///// functions
function fun(name:any):any{
    return name
}

var res :string= fun("hhhhh")
