///api result 
////status:number
////msg:string
////data:null|product[]|any


class ApIResult<kero>{
   status:number
    msg:string
data:kero 
}



///use
let op1 :ApIResult<number>
op1.data =99
let op2 :ApIResult<string[]|Number[]>



class Queue<type> {
    items:type[]

    
    add(item:type){
        this.items.push(item)
    }

}