function greeting(name){
  console.log(`Hi ${name}`)  
}
greeting("hehhhhhhh")