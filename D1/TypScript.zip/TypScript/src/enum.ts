export enum gender{
    male = 0,
    female = 1
}
enum Color{
    red ='rgb(255,0,0)',
    green = "rgb(0,255,0)",
    blue = "rgb(0,0,255)"
}

enum test{
    one =1,
    two ="2"
}

//use
var m :gender =gender.female
var c = Color.blue


console.log(Object.keys(gender))
console.log(gender[0])
