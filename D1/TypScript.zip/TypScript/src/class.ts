class Person{
    static count:number = 0
    Name:string;
    private age:number;
    protected gender :boolean;
    constructor(name:string){
        this.Name = name
        this .age= 18
        this.gender = true
    }
}

Person.count
class Student extends Person{
    protected track:string|number;
    private TotalGrade:number;
    public departmant:string;
///declaratin
    constructor();
    constructor(name:string);
    constructor(name:string,tr:string,dep:string)
    constructor(name:string,tr:number,dep:string)
    constructor(name:string,tr:string,dep:string,tg:number)

///implementation
    constructor(name?:string,tr?:string|number,dep?:string,tg?:number)
    {
        // if(tr===undefined){
        //     console.log("used empty constravto")
        // }
        super(name)//con
        this.TotalGrade = tg===undefined?0:tg;
        this.departmant = dep==undefined?"dummy":dep;
        this.track = tr===undefined?"dummy":tr
        super.gender = false
        
    }
    display(){
        console.log(super.Name)
    }
}

// var a:Student = new Student("f&CP","SD",66)
// var b:Student = new Student("f&CP","SD")
var c:Student = new Student("ali")
console.log(c.Name)
c.display()


